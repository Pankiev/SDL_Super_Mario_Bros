
#pragma once

#include "GameBase.h"

class ManyElementsObject : public GameBase
{
public:

    ManyElementsObject(MarioGame& game)

};
