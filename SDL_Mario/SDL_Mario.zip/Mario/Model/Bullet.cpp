/*
#include "Bullet.h"

Bullet::Bullet(MarioGame& game):Mob(game)
{

}

void Bullet::marioJumped()
{
    die();
}
*/
