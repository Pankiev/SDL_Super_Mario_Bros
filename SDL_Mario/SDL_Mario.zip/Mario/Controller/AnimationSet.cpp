
#include "AnimationSet.h"

AnimationSet::AnimationSet(AbstractMob& owner):owner_(owner)
{

}

