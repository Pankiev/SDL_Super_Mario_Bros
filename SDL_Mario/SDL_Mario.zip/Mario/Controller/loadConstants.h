
enum
{
    LOAD_TEXTURE = 0,
    LOAD_SHOW_X = 1,
    LOAD_SHOW_Y = 2,
    LOAD_SHOW_WIDTH = 3,
    LOAD_SHOW_HEIGHT = 4,
    LOAD_COLL_X = 5,
    LOAD_COLL_Y = 6,
    LOAD_COLL_WIDTH = 7,
    LOAD_COLL_HEIGHT = 8
};
